SPRITES USADOS EN ESTA VERSION

player_sheet.png = sprite exacto proporcionado por el usuario (792x792).
enemies_sheet.png = sprite exacto proporcionado por el usuario (724x724).

El juego carga estos archivos directamente. Los sprites anteriores no se usan para el juego principal.

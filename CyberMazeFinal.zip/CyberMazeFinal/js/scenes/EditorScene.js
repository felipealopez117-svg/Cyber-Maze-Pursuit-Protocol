export class EditorScene{enter(){}update(){}draw(){}}

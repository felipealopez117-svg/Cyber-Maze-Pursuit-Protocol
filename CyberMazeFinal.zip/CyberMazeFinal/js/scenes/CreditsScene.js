export class CreditsScene{enter(){}update(){}draw(){}}

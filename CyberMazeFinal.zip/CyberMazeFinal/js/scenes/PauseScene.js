export class PauseScene{enter(){}update(){}draw(){}}

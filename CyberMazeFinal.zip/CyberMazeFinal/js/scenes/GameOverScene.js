export class GameOverScene{enter(){}update(){}draw(){}}

export class MenuScene{enter(){}update(){}draw(){}}

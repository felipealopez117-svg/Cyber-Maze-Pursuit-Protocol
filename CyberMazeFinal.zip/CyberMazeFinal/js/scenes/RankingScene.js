export class RankingScene{enter(){}update(){}draw(){}}

export class AISystem{update(game,dt){for(const e of game.enemies)e.update(dt,game)}}
